<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Notifications\DatabaseNotification;

class NotificationController extends Controller
{
    /**
     * Fetch all notifications for the authenticated user.
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function fetchNotifications(Request $request)
    {
        $notifications = $request->user()->unreadNotifications;

        return response()->json([
            'notifications' => $notifications,
        ]);
    }

    /**
     * Mark a notification as read.
     *
     * @param Request $request
     * @param DatabaseNotification $notification
     * @return \Illuminate\Http\RedirectResponse
     */
    public function markAsRead(Request $request, $id)
    {
        $notification = $request->user()->notifications()->find($id);

        if ($notification) {
            $notification->markAsRead();
        }

        return response()->json([
            'success' => true,
        ]);
    }

    /**
     * Mark all notifications as read.
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function clearAllNotifications(Request $request)
    {
        $request->user()->unreadNotifications->markAsRead();

        return response()->json([
            'success' => true,
        ]);
    }

    /**
     * Dismiss a notification (delete it).
     *
     * @param Request $request
     * @param DatabaseNotification $notification
     * @return \Illuminate\Http\JsonResponse
     */
    public function dismissNotification(Request $request, $id)
    {
        $notification = $request->user()->notifications()->find($id);

        if ($notification) {
            $notification->delete();
        }

        return response()->json([
            'success' => true,
        ]);
    }
}
