<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('User Details')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">

                    <!-- User Details -->
                    <h3 class="text-xl font-bold mb-4">User Information</h3>
                    <div class="flex items-center mb-6">
                        <img src="<?php echo e(asset('storage/' . $user->image)); ?>" alt="User Image" class="w-24 h-24 rounded-full">
                        <div class="ml-6">
                            <p><strong>Name:</strong> <?php echo e($user->name); ?></p>
                            <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
                            <p><strong>Phone:</strong> <?php echo e($user->phone); ?></p>
                            <?php if(auth()->user()->role_id != 2): ?> <!-- Check if logged-in user is NOT admin -->
                            <p><strong>Role:</strong> <?php echo e($user->role->name ?? 'N/A'); ?></p>
                            <?php endif; ?>
                            <p><strong>Status:</strong> <?php echo e($user->is_active ? 'Active' : 'Inactive'); ?></p>
                        </div>
                    </div>

                    <!-- Conditional Content -->
                    <!-- Actions or Activity History -->
                    <?php if($user->role_id == 1 || $user->role_id == 2): ?>
                    <h3 class="text-xl font-bold mb-4">Activity History</h3>
                    <table class="table-auto w-full mb-6">
                        <thead>
                            <tr>
                                <th class="border px-4 py-2">Action</th>
                                <th class="border px-4 py-2">Details</th>
                                <th class="border px-4 py-2">Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $auditLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="border px-4 py-2"><?php echo e($log->action); ?></td>
                                <td class="border px-4 py-2"><?php echo e($log->details); ?></td>
                                <td class="border px-4 py-2"><?php echo e($log->created_at->format('d/m/Y H:i:s')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3" class="border px-4 py-2 text-center">No actions recorded.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="mt-4">
                        <?php echo e($auditLogs->links()); ?>

                    </div>
                    <?php else: ?>
                    <!-- Address Details -->
                    <h3 class="text-xl font-bold mb-4">Address Information</h3>
                    <div class="mb-6">
                        <?php $__currentLoopData = $user->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-4">
                            <p><strong>Street Address:</strong> <?php echo e($address->street_address); ?></p>
                            <p><strong>City:</strong> <?php echo e($address->city); ?></p>
                            <p><strong>State:</strong> <?php echo e($address->state); ?></p>
                            <p><strong>Zip Code:</strong> <?php echo e($address->zip_code); ?></p>
                            <p><strong>Country:</strong> <?php echo e($address->country); ?></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <!-- Order History -->
                    <h3 class="text-xl font-bold mb-4">Order History</h3>
                    <table class="table-auto w-full mb-6">
                        <thead>
                            <tr>
                                <th class="border px-4 py-2">Order ID</th>
                                <th class="border px-4 py-2">Total Price</th>
                                <th class="border px-4 py-2">Coupon Discount</th>
                                <th class="border px-4 py-2">Status</th>
                                <th class="border px-4 py-2">Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="border px-4 py-2"><?php echo e($order->id); ?></td>
                                <td class="border px-4 py-2">$<?php echo e(number_format($order->total_price, 2)); ?></td>
                                <td class="border px-4 py-2">
                                    <?php if($order->coupon): ?>
                                    <span><?php echo e($order->coupon->code); ?> (<?php echo e($order->coupon->discount_percentage); ?>%)</span>
                                    <?php else: ?>
                                    <span>N/A</span>
                                    <?php endif; ?>
                                </td>
                                <td class="border px-4 py-2">
                                    <span class="
                    <?php if($order->status->name === 'completed'): ?> text-green-500 font-bold 
                    <?php elseif($order->status->name === 'pending'): ?> text-yellow-500 font-bold 
                    <?php elseif($order->status->name === 'canceled'): ?> text-red-500 font-bold 
                    <?php else: ?> text-gray-500 
                    <?php endif; ?>">
                                        <?php echo e($order->status->name ?? 'N/A'); ?>

                                    </span>
                                </td>
                                <td class="border px-4 py-2"><?php echo e($order->created_at->format('d/m/Y')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="border px-4 py-2 text-center text-gray-500">
                                    No orders available. Start shopping to place your first order!
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <div class="mt-4">
                        <?php echo e($orders->links()); ?>

                    </div>
                    <?php endif; ?>
                    <!-- Actions -->
                    <h3 class="text-xl font-bold mb-4">Actions</h3>
                    <div class="flex space-x-4">
                        <form action="<?php echo e(route('users.toggleStatus', $user->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                                <?php echo e($user->is_active ? 'Deactivate' : 'Activate'); ?>

                            </button>
                        </form>
                        <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                                Delete
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\Orange\Desktop\OrangeCodingAcademy\demo-test\resources\views/admin/users/show.blade.php ENDPATH**/ ?>