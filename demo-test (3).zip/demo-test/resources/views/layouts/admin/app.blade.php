<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <style>
        #sidebar {
            transition: transform 0.3s ease-in-out;
        }

        #main-content {
            transition: margin-left 0.3s ease-in-out;
        }
    </style>
</head>

<body class="font-sans antialiased">
    <div class="flex">
        <!-- Sidebar -->
        @include('layouts.sidebar')

        <!-- Main Content -->
        <div id="main-content" class="flex-1 min-h-screen bg-gray-100 dark:bg-gray-900 transition-all duration-300">
            <!-- Navigation -->
            @include('layouts.navigation')

            <!-- Page Content -->
            <main>
                {{ $slot }}
            </main>
        </div>
    </div>
    <!-- Sidebar Toggle Script -->
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const sidebar = document.getElementById("sidebar");
            const mainContent = document.getElementById("main-content");
            const navbarToggle = document.getElementById("navbar-sidebar-toggle");
            const sidebarToggleButtons = document.querySelectorAll("#navbar-sidebar-toggle");

            sidebarToggleButtons.forEach((button) => {
                button.addEventListener("click", () => {
                    sidebar.classList.toggle("-translate-x-full");

                    if (sidebar.classList.contains("-translate-x-full")) {
                        mainContent.style.marginLeft = "0";
                    } else {
                        mainContent.style.marginLeft = "16rem";
                    }
                });
            });

            if (window.innerWidth >= 768) {
                sidebar.classList.remove("-translate-x-full");
                mainContent.style.marginLeft = "16rem";
            } else {
                sidebar.classList.add("-translate-x-full");
                mainContent.style.marginLeft = "0";
            }
        });
    </script>

    <script>
        document.addEventListener("alpine:init", () => {
            Alpine.data('notifications', () => ({
                notifications: [],
                loading: true,
                dropdownOpen: false,

                // Fetch notifications from the backend
                fetchNotifications() {
                    fetch('/notifications')
                        .then(res => res.json())
                        .then(data => {
                            this.notifications = data.notifications;
                            this.loading = false;
                        })
                        .catch(() => {
                            this.loading = false;
                        });
                },

                // Mark a notification as read
                markAsRead(notificationId) {
                    fetch(`/notifications/${notificationId}/read`, {
                            method: 'PUT',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                            }
                        })
                        .then(response => {
                            if (response.ok) {
                                const notification = this.notifications.find(n => n.id === notificationId);
                                if (notification) {
                                    notification.read_at = true; // Update read status in local state
                                }
                            }
                        });
                },

                // Dismiss (delete) a notification
                dismissNotification(notificationId) {
                    fetch(`/notifications/${notificationId}/dismiss`, {
                            method: 'DELETE',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                            }
                        })
                        .then(response => {
                            if (response.ok) {
                                this.notifications = this.notifications.filter(n => n.id !== notificationId);
                            }
                        });
                },

                // Clear all notifications
                clearAllNotifications() {
                    fetch('/notifications/clear', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                            }
                        })
                        .then(response => {
                            if (response.ok) {
                                // Mark all notifications as read
                                this.notifications.forEach(n => {
                                    n.read_at = true;
                                });
                            }
                        });
                },

                // Initialize fetching notifications
                init() {
                    this.fetchNotifications();
                }
            }));
        });
    </script>

</body>

</html>