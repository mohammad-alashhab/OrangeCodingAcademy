<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        #sidebar {
            transition: transform 0.3s ease-in-out;
        }

        #main-content {
            transition: margin-left 0.3s ease-in-out;
        }
    </style>
</head>

<body class="font-sans antialiased">
    <div class="flex">
        <!-- Sidebar -->
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Main Content -->
        <div id="main-content" class="flex-1 min-h-screen bg-gray-100 dark:bg-gray-900 transition-all duration-300">
            <!-- Navigation -->
            <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Page Content -->
            <main>
                <?php echo e($slot); ?>

            </main>
        </div>
    </div>
    <!-- Sidebar Toggle Script -->
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const sidebar = document.getElementById("sidebar");
            const mainContent = document.getElementById("main-content");
            const navbarToggle = document.getElementById("navbar-sidebar-toggle");
            const sidebarToggleButtons = document.querySelectorAll("#navbar-sidebar-toggle");

            sidebarToggleButtons.forEach((button) => {
                button.addEventListener("click", () => {
                    sidebar.classList.toggle("-translate-x-full");

                    if (sidebar.classList.contains("-translate-x-full")) {
                        mainContent.style.marginLeft = "0";
                    } else {
                        mainContent.style.marginLeft = "16rem";
                    }
                });
            });

            if (window.innerWidth >= 768) {
                sidebar.classList.remove("-translate-x-full");
                mainContent.style.marginLeft = "16rem";
            } else {
                sidebar.classList.add("-translate-x-full");
                mainContent.style.marginLeft = "0";
            }
        });
    </script>
    <script>
        const themeToggle = document.getElementById('theme-toggle');
        const html = document.documentElement;

        // Check localStorage for theme preference
        if (localStorage.getItem('theme') === 'dark') {
            html.classList.add('dark');
        }

        themeToggle.addEventListener('click', () => {
            if (html.classList.contains('dark')) {
                html.classList.remove('dark');
                localStorage.setItem('theme', 'light');
            } else {
                html.classList.add('dark');
                localStorage.setItem('theme', 'dark');
            }
        });
    </script>

</body>

</html><?php /**PATH C:\Users\Orange\Desktop\OrangeCodingAcademy\demo-test\resources\views/layouts/admin/app.blade.php ENDPATH**/ ?>