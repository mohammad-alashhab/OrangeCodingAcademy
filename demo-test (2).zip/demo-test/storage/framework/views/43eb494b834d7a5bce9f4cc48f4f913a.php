<?php if($paginator->hasPages()): ?>
<nav>
    <ul class="pagination">
        
        <?php if($paginator->onFirstPage()): ?>
        <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
            <span class="page-link" aria-hidden="true">&lsaquo;</span>
        </li>
        <?php else: ?>
        <li class="page-item">
            <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">&lsaquo;</a>
        </li>
        <?php endif; ?>

        
        <?php
        $current = $paginator->currentPage();
        $last = $paginator->lastPage();
        $start = max(1, $current - 1);
        $end = min($last, $current + 1);
        ?>

        
        <?php if($start > 2): ?>
        <li class="page-item"><a class="page-link" href="<?php echo e($paginator->url(1)); ?>">1</a></li>
        <?php if($start > 3): ?>
        <li class="page-item disabled" aria-disabled="true"><span class="page-link">...</span></li>
        <?php endif; ?>
        <?php endif; ?>

        
        <?php for($page = $start; $page <= $end; $page++): ?>
            <?php if($page==$current): ?>
            <li class="page-item active" aria-current="page"><span class="page-link"><?php echo e($page); ?></span></li>
            <?php else: ?>
            <li class="page-item"><a class="page-link" href="<?php echo e($paginator->url($page)); ?>"><?php echo e($page); ?></a></li>
            <?php endif; ?>
            <?php endfor; ?>

            
            <?php if($end < $last - 1): ?>
                <li class="page-item disabled" aria-disabled="true"><span class="page-link">...</span></li>
                <li class="page-item"><a class="page-link" href="<?php echo e($paginator->url($last)); ?>"><?php echo e($last); ?></a></li>
                <?php elseif($end == $last - 1): ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($paginator->url($last)); ?>"><?php echo e($last); ?></a></li>
                <?php endif; ?>

                
                <?php if($paginator->hasMorePages()): ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">&rsaquo;</a>
                </li>
                <?php else: ?>
                <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                    <span class="page-link" aria-hidden="true">&rsaquo;</span>
                </li>
                <?php endif; ?>
    </ul>
</nav>
<?php endif; ?><?php /**PATH C:\Users\Orange\Desktop\OrangeCodingAcademy\demo-test\resources\views/vendor/pagination/bootstrap-4.blade.php ENDPATH**/ ?>