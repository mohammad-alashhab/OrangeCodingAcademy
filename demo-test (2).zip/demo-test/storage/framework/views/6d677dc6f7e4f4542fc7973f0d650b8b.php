<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Review Details')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm sm:rounded-lg p-6">

                <!-- Review Details -->
                <div class="mb-6">
                    <h3 class="font-semibold text-lg mb-4"><?php echo e(__('Review Information')); ?></h3>
                    <p><strong><?php echo e(__('User:')); ?></strong> <?php echo e($review->user->name ?? 'N/A'); ?></p>
                    <p><strong><?php echo e(__('Item:')); ?></strong> <?php echo e(ucfirst($review->product->name ?? 'N/A')); ?></p>

                    <p><strong><?php echo e(__('Rating:')); ?></strong>
                        <!-- Rating as stars -->
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <span class="text-yellow-500">
                            <?php if($i <= $review->rating): ?>
                                ★
                                <?php else: ?>
                                ☆
                                <?php endif; ?>
                                </span>
                                <?php endfor; ?>
                    </p>

                    <p><strong><?php echo e(__('Comment:')); ?></strong> <?php echo e($review->comment); ?></p>
                    <p><strong><?php echo e(__('Visibility:')); ?></strong> <?php echo e($review->is_visible ? 'Visible' : 'Hidden'); ?></p>
                    <p><strong><?php echo e(__('Created At:')); ?></strong> <?php echo e($review->created_at); ?></p>
                    <p><strong><?php echo e(__('Updated At:')); ?></strong> <?php echo e($review->updated_at); ?></p>
                </div>


                <!-- Actions -->
                <form action="<?php echo e(route('reviews.toggleVisibility', $review->id)); ?>" method="POST" class="mt-4">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-<?php echo e($review->is_visible ? 'danger' : 'success'); ?>">
                        <?php echo e($review->is_visible ? __('Hide') : __('Make Visible')); ?>

                    </button>
                    <a href="<?php echo e(route('reviews.index')); ?>" class="btn btn-secondary">
                        <?php echo e(__('Back')); ?>

                    </a>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\Orange\Desktop\OrangeCodingAcademy\demo-test\resources\views/admin/reviews/show.blade.php ENDPATH**/ ?>