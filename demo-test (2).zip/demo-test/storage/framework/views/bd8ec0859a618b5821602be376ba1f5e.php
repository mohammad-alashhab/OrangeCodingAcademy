<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('User Details')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">

                    <!-- User Details -->
                    <h3 class="text-xl font-bold mb-4">User Information</h3>
                    <div class="flex items-center mb-6">
                        <img src="<?php echo e(asset($user->image)); ?>" alt="User Image" class="w-24 h-24 rounded-full">
                        <div class="ml-6">
                            <p><strong>Name:</strong> <?php echo e($user->name); ?></p>
                            <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
                            <p><strong>Phone:</strong> <?php echo e($user->phone); ?></p>
                            <p><strong>Role:</strong> <?php echo e($user->role->name ?? 'N/A'); ?></p>
                            <p><strong>Status:</strong> <?php echo e($user->is_active ? 'Active' : 'Inactive'); ?></p>
                        </div>
                    </div>

                    <!-- Address Details -->
                    <h3 class="text-xl font-bold mb-4">Address Information</h3>
                    <div class="mb-6">
                        <?php $__currentLoopData = $user->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-4">
                            <p><strong>Address Type:</strong> <?php echo e($address->address_type); ?></p>
                            <p><strong>Street Address:</strong> <?php echo e($address->street_address); ?></p>
                            <p><strong>City:</strong> <?php echo e($address->city); ?></p>
                            <p><strong>State:</strong> <?php echo e($address->state); ?></p>
                            <p><strong>Zip Code:</strong> <?php echo e($address->zip_code); ?></p>
                            <p><strong>Country:</strong> <?php echo e($address->country); ?></p>
                            <p><strong>Default Address:</strong> <?php echo e($address->default_address ? 'Yes' : 'No'); ?></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <!-- Order History -->
                    <h3 class="text-xl font-bold mb-4">Order History</h3>
                    <table class="table-auto w-full mb-6">
                        <thead>
                            <tr>
                                <th class="border px-4 py-2">Order ID</th>
                                <th class="border px-4 py-2">Total Price</th>
                                <th class="border px-4 py-2">Product Quantity</th>
                                <th class="border px-4 py-2">Status</th>
                                <th class="border px-4 py-2">Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="border px-4 py-2"><?php echo e($order->id); ?></td>
                                <td class="border px-4 py-2">$<?php echo e($order->total_price); ?></td>
                                <td class="border px-4 py-2"><?php echo e($order->product_quantity); ?></td>
                                <td class="border px-4 py-2"><?php echo e($order->status->name ?? 'N/A'); ?></td>
                                <td class="border px-4 py-2"><?php echo e($order->created_at->format('d/m/Y')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="border px-4 py-2 text-center">No orders found.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <!-- Actions -->
                    <h3 class="text-xl font-bold mb-4">Actions</h3>
                    <div class="flex space-x-4">
                        <form action="<?php echo e(route('users.toggleStatus', $user->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                                <?php echo e($user->is_active ? 'Deactivate' : 'Activate'); ?>

                            </button>
                        </form>
                        <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                                Delete
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\Orange\Desktop\demo-test\resources\views/admin/users/show.blade.php ENDPATH**/ ?>