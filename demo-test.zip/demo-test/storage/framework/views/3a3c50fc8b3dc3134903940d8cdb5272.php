<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Discounts')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="px-6 py-4">
                    <div class="flex justify-between items-center">
                        <form method="GET" action="<?php echo e(route('discounts.index')); ?>" class="flex items-center">
                            <input
                                type="text"
                                name="search"
                                value="<?php echo e(request('search')); ?>"
                                placeholder="Search Discounts..."
                                class="border border-gray-300 rounded px-3 py-2 focus:outline-none" />
                            <button type="submit" class="ml-2 btn btn-primary">Search</button>
                        </form>
                        <a href="<?php echo e(route('discounts.create')); ?>" class="btn btn-primary">Create Discount</a>
                    </div>
                    <table class="table mt-3 w-full">
                        <thead>
                            <tr>
                                <th class="px-4 py-2">Product</th>
                                <th class="px-4 py-2">Price</th>
                                <th class="px-4 py-2">Discount (%)</th>
                                <th class="px-4 py-2">Start Date</th>
                                <th class="px-4 py-2">End Date</th>
                                <th class="px-4 py-2">Status</th>
                                <th class="px-4 py-2">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-4 py-2"><?php echo e($discount->product->name); ?></td>
                                <td class="px-4 py-2"><?php echo e(number_format($discount->product->price, 2)); ?></td>
                                <td class="px-4 py-2"><?php echo e($discount->percentage); ?>%</td>
                                <td class="px-4 py-2"><?php echo e($discount->startdate); ?></td>
                                <td class="px-4 py-2"><?php echo e($discount->enddate); ?></td>
                                <td class="px-4 py-2"><?php echo e($discount->is_active ? 'Active' : 'Inactive'); ?></td>
                                <td class="px-4 py-2">
                                    <a href="<?php echo e(route('discounts.edit', $discount->id)); ?>" class="btn btn-warning">Edit</a>
                                    <form action="<?php echo e(route('discounts.destroy', $discount->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                    <?php if(now()->greaterThanOrEqualTo($discount->enddate)): ?>
                                    <span class="text-red-500">Expired</span>
                                    <?php else: ?>
                                    <form action="<?php echo e(route('discounts.toggleStatus', $discount->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-info">
                                            <?php echo e($discount->is_active ? 'Deactivate' : 'Activate'); ?>

                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4">No discounts found.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php echo e($discounts->links()); ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\Orange\Desktop\OrangeCodingAcademy\demo-test\resources\views/admin/discounts/index.blade.php ENDPATH**/ ?>